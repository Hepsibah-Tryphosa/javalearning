public class Viewer {

String name;
String mail;
int count;


    
}
