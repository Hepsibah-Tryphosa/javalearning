

public class MainEmp {
    public static void main(String[] args) {

        // Employee e1 = new Employee(1, "a", "ece", "3");
        // Employee e2 = new Employee(2, "b", "cse", "3");
        // Employee e3 = new Employee(3, "c", "eee", "3");
        // Employee e4 = new Employee(4, "d", "mech", "3");
        // Employee e5 = new Employee(5, "e", "it", "3");

        // System.out.println(e1);
        // System.out.println(e2);
        // System.out.println(e3);
        // System.out.println(e4);
        // System.out.println(e5);

         Author a=new Author("sweety", "sweety@gmail.com", "f");
         Book b = new Book("Harry Potter", a, 350.0, 1);
         System.out.println(b);

    }
}