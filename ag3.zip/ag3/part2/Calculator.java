public interface Calculator {

    void addition();

    void subtraction();

    void multiplication();

    double division();
}