public class AuthorReadOnly{
    private String name;
    private String gender;

    
    public AuthorReadOnly(String name, String gender) {
        this.name = name;
        this.gender = gender;
    }


    public String getName() {
        return name;
    }


    public String getGender() {
        return gender;
    }




    

}
