import java.util.List;

public class Channel {
    String name;
    

}
